# Minimal Runtime Contract

Classification: NORMATIVE

- Runtime mode: `RUNTIME`
- Controlled Execution: enabled
- Workflow specification: `runtime/domain/workflow.py`
- Public execution entrypoint: `runtime/public_api.py`
- Embedded control runtime: `runtime/control/`
- Receipt authority: controller-generated Receipt chain
- Artifact authority: `runtime/control/provenance.py` plus Domain-declared Artifact Validator
- Full ChatGPT Bundle Framework package: not required at runtime
- Source of Truth: `spec/SOURCE_OF_TRUTH.md`
