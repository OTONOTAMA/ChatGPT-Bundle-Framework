# SYNTHETIC_NUMBER_SUMMARY_BUNDLE — Canonical Domain Specification

Classification: NORMATIVE / PRIMARY_CANONICAL_SOURCE

## Objective

Given a non-empty list of integers, produce a formal summary artifact containing count, sum, minimum, maximum, and an exact numerator/denominator representation plus six-decimal display of the arithmetic mean.

## Formal workflow

The only formal runtime route is the declared public entrypoint `runtime/public_api.py` using the `formal` command. Formal execution uses the embedded generic controlled-execution runtime.

Declared actions, in order for this reference workflow:

1. `VALIDATE_INPUT`
2. `CALCULATE_SUMMARY`
3. `FINALIZE_ARTIFACT`

Formal completion requires terminal authority `EMISSION_AUTHORIZED`, a valid final Receipt, and Artifact Validator PASS.

## Input contract

- `values` is a non-empty list.
- Maximum 100 values.
- Every value must be an integer and must not be a boolean.

## Output contract

The formal artifact must be identical to the authoritative result produced by `FINALIZE_ARTIFACT` and must satisfy the declared Artifact Validator.

## Failure policy

Invalid required input is a failure. Missing formal authority evidence must not be represented as formal success. Correct-looking output produced by an unauthorized route remains non-authoritative.
