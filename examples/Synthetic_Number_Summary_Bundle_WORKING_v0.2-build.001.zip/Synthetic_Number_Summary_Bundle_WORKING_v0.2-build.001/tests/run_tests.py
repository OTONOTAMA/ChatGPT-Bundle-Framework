from __future__ import annotations
import hashlib, json, subprocess, sys
from pathlib import Path
import yaml

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from runtime.public_api import run_formal, run_adversarial

checks=[]
def check(name, ok):
    checks.append((name, bool(ok)))
    if not ok: raise AssertionError(name)

def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

manifest=yaml.safe_load((ROOT/'bundle.yaml').read_text())
required_manifest=['bundle_id','bundle_name','bundle_version','framework_version','bundle_type','objective','required_components','source_of_truth','dependencies','entrypoint','bootstrap_policy','runtime_contract','language_policy','compatibility','release_state']
check('manifest_required_fields', all(k in manifest for k in required_manifest))
check('minimal_structure', all((ROOT/p).exists() for p in ['bundle.yaml','bundle.lock.yaml','runtime','spec','tests']))
check('source_of_truth_resolves', (ROOT/manifest['source_of_truth']['primary']).is_file())
check('entrypoint_resolves', (ROOT/manifest['entrypoint']).is_file())
ce=manifest['runtime_contract']['controlled_execution']
check('controlled_execution_declared', ce['enabled'] is True and all((ROOT/ce[k]).exists() for k in ['workflow_spec_reference','public_execution_entrypoint','receipt_policy_reference','artifact_authority_policy_reference']))

lock=yaml.safe_load((ROOT/'bundle.lock.yaml').read_text())
for item in lock['exact_component_files']:
    p=ROOT/item['path']
    check('lock_'+item['path'], p.is_file() and p.stat().st_size==item['size'] and sha256(p)==item['sha256'])

formal=run_formal([12,7,31,10])
s=formal['artifact']['summary']
check('formal_summary', s['count']==4 and s['sum']==60 and s['minimum']==7 and s['maximum']==31 and s['mean_decimal']=='15.000000')
check('formal_three_receipts', len(formal['receipt_ids'])==3)
check('emission_authority', formal['provenance']['authority_status']=='EMISSION_AUTHORIZED')
check('artifact_validator_pass', formal['provenance']['artifact_validation_status']=='PASS')
adv=run_adversarial([12,7,31,10])
check('adversarial_all_pass', adv['status']=='PASS' and len(adv['checks'])==3 and all(c['pass'] for c in adv['checks']))
check('runtime_self_contained', manifest['compatibility']['full_framework_runtime_dependency'] is False)

print(json.dumps({'status':'PASS','checks':len(checks)}, indent=2))
