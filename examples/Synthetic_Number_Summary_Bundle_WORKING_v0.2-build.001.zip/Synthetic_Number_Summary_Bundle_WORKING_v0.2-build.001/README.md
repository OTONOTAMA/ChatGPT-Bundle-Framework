# Synthetic Number Summary Bundle — WORKING v0.2 build.001

Purpose: full-package clean-room validation of ChatGPT Bundle Framework v0.1 plus Controlled Execution.

Unlike the earlier controlled-execution-only synthetic test artifact, this build includes the required v0.1 `bundle.yaml`, `bundle.lock.yaml`, `runtime/`, `spec/`, and `tests/` structure.

## Bootstrap

```bash
python bootstrap.py
```

## Formal sample

```bash
python runtime/public_api.py formal 12 7 31 10
```

Expected summary: count 4, sum 60, minimum 7, maximum 31, mean 15.000000.

## Adversarial probe

```bash
python runtime/public_api.py adversarial 12 7 31 10
```

Status: SYNTHETIC_TEST_BUNDLE / PREVIEW / WORKING build.001
