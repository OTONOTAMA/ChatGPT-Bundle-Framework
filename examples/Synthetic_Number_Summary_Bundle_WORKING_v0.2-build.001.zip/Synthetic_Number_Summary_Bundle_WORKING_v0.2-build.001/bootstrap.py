from __future__ import annotations
import hashlib, json, subprocess, sys
from pathlib import Path
import yaml
ROOT=Path(__file__).resolve().parent

def sha256(p): return hashlib.sha256(p.read_bytes()).hexdigest()
manifest=yaml.safe_load((ROOT/'bundle.yaml').read_text())
lock=yaml.safe_load((ROOT/'bundle.lock.yaml').read_text())
required=['bundle.lock.yaml','runtime','spec','tests']
for x in required:
    if not (ROOT/x).exists(): raise SystemExit(f'MISSING_REQUIRED:{x}')
for item in lock['exact_component_files']:
    p=ROOT/item['path']
    if not p.is_file() or p.stat().st_size!=item['size'] or sha256(p)!=item['sha256']:
        raise SystemExit(f'INTEGRITY_FAIL:{item["path"]}')
proc=subprocess.run([sys.executable,str(ROOT/'tests/run_tests.py')],cwd=ROOT,text=True,capture_output=True)
if proc.returncode!=0:
    print(proc.stdout); print(proc.stderr,file=sys.stderr); raise SystemExit('TEST_FAIL')
print(json.dumps({
  'bundle_id':manifest['bundle_id'],
  'bundle_version':manifest['bundle_version'],
  'framework_version':manifest['framework_version'],
  'source_of_truth':manifest['source_of_truth']['primary'],
  'release_state':manifest['release_state'],
  'validation':'PASS',
  'state':'RUNTIME_READY'
},indent=2))
