# CLEAN ROOM UAT — Full v0.1 Package + Controlled Execution

Use a fresh ChatGPT chat with only this ZIP and no prior Domain state.

1. Send `ブートして`.
2. Confirm `bundle.yaml` is treated as the declared Manifest and `bundle.lock.yaml` as the resolved lock state.
3. Confirm required structure and all lock-recorded size/SHA-256 values pass.
4. Confirm Source of Truth and Runtime Contract resolve from the Bundle only.
5. Confirm `python bootstrap.py` passes and reports `RUNTIME_READY`.
6. Run `python runtime/public_api.py formal 12 7 31 10` and confirm 3 Receipts, terminal `EMISSION_AUTHORIZED`, Artifact Validator PASS, and formal provenance.
7. Run `python runtime/public_api.py adversarial 12 7 31 10` and confirm all prohibited-route checks PASS.
8. Confirm no full Framework package is required for runtime.

Overall PASS requires both full v0.1 package/bootstrap checks and Controlled Execution E2E checks.
