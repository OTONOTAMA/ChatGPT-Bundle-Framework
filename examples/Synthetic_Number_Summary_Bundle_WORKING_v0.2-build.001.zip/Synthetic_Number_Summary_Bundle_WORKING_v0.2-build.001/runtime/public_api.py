from __future__ import annotations
import argparse
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from runtime.control.state_controller import StateController, AuthorityError
from runtime.control.provenance import create_artifact_provenance
from runtime.domain.workflow import WORKFLOW, EXECUTORS, ARTIFACT_VALIDATORS


def build_controller():
    return StateController(WORKFLOW, EXECUTORS, ARTIFACT_VALIDATORS)


def run_formal(values):
    controller = build_controller()
    start = controller.begin_workflow({"values": values})
    wid = start["current_state"]["workflow_instance_id"]
    results = []
    while True:
        step = controller.advance(wid)
        if step["result"] == "WORKFLOW_COMPLETED":
            break
        results.append(step)
        if step["current_state"]["status"] == "COMPLETED":
            break
    final = results[-1]
    artifact = final["output"]
    provenance = create_artifact_provenance(
        controller=controller,
        workflow_instance_id=wid,
        final_receipt_id=final["receipt"]["receipt_id"],
        artifact=artifact,
        output_contract_id=WORKFLOW["output_contract"]["id"],
        output_contract_version=WORKFLOW["output_contract"]["version"],
        authoritative_result=final["output"],
    )
    return {
        "status": "PASS",
        "route": "PUBLIC_AUTHORIZED",
        "workflow_instance_id": wid,
        "actions": [r["action_id"] for r in results],
        "receipt_ids": [r["receipt"]["receipt_id"] for r in results],
        "artifact": artifact,
        "provenance": provenance,
        "final_state": controller.inspect_state(wid)["current_state"],
    }


def run_adversarial(values):
    checks = []
    controller = build_controller()
    start = controller.begin_workflow({"values": values})
    wid = start["current_state"]["workflow_instance_id"]

    before = controller.inspect_state(wid)["current_state"].copy()
    shortcut = controller.execute_internal_without_permit(wid, "FINALIZE_ARTIFACT_EXECUTOR")
    after = controller.inspect_state(wid)["current_state"]
    checks.append({
        "check": "DIRECT_INTERNAL_SHORTCUT_NONAUTHORITATIVE",
        "pass": shortcut["authority"] == "NON_AUTHORITATIVE" and before == after and after["last_receipt_id"] is None,
    })

    # Complete the authorized route.
    r1 = controller.advance(wid)
    r2 = controller.advance(wid)
    r3 = controller.advance(wid)
    final_artifact = r3["output"]

    forged = json.loads(json.dumps(final_artifact))
    forged["summary"]["sum"] += 1
    rejected = False
    try:
        create_artifact_provenance(
            controller=controller,
            workflow_instance_id=wid,
            final_receipt_id=r3["receipt"]["receipt_id"],
            artifact=forged,
            output_contract_id=WORKFLOW["output_contract"]["id"],
            output_contract_version=WORKFLOW["output_contract"]["version"],
            authoritative_result=final_artifact,
        )
    except AuthorityError:
        rejected = True
    checks.append({"check": "ALTERED_ARTIFACT_REJECTED", "pass": rejected})

    old_receipt = r3["receipt"]["receipt_id"]
    controller.commit_canonical_input(wid, {"values": values + [99]}, "RESOLVED")
    checks.append({
        "check": "STALE_FINAL_RECEIPT_INVALID_AFTER_INPUT_CHANGE",
        "pass": controller.validate_receipt(old_receipt) is False,
    })

    return {
        "status": "PASS" if all(c["pass"] for c in checks) else "FAIL",
        "checks": checks,
    }


def main():
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    f = sub.add_parser("formal")
    f.add_argument("values", nargs="+", type=int)
    a = sub.add_parser("adversarial")
    a.add_argument("values", nargs="+", type=int)
    args = parser.parse_args()
    if args.command == "formal":
        out = run_formal(args.values)
    else:
        out = run_adversarial(args.values)
    print(json.dumps(out, ensure_ascii=False, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
