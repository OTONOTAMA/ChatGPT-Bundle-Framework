"""Synthetic Number Summary domain workflow.

This file intentionally contains domain-specific behavior. The copied control runtime
remains generic and does not depend on this domain.
"""
from __future__ import annotations
from typing import Any, Dict


def _values(payload: Dict[str, Any]):
    values = payload.get("values")
    if not isinstance(values, list) or not values:
        raise ValueError("values must be a non-empty list")
    if len(values) > 100:
        raise ValueError("values exceeds synthetic test limit")
    if any(isinstance(v, bool) or not isinstance(v, int) for v in values):
        raise ValueError("all values must be integers")
    return values


def validate_input(payload: Dict[str, Any]) -> Dict[str, Any]:
    values = _values(payload)
    return {"validated": True, "count": len(values)}


def calculate_summary(payload: Dict[str, Any]) -> Dict[str, Any]:
    values = _values(payload)
    total = sum(values)
    n = len(values)
    return {
        "count": n,
        "sum": total,
        "minimum": min(values),
        "maximum": max(values),
        "mean_numerator": total,
        "mean_denominator": n,
        "mean_decimal": f"{total / n:.6f}",
    }


def finalize_artifact(payload: Dict[str, Any]) -> Dict[str, Any]:
    values = _values(payload)
    return {
        "artifact_type": "SYNTHETIC_NUMBER_SUMMARY",
        "artifact_schema_version": "1",
        "input": {"values": list(values)},
        "summary": calculate_summary(payload),
    }


def validate_formal_artifact(artifact: Any, authoritative_result: Any) -> bool:
    if not isinstance(artifact, dict) or not isinstance(authoritative_result, dict):
        return False
    if artifact != authoritative_result:
        return False
    return (
        artifact.get("artifact_type") == "SYNTHETIC_NUMBER_SUMMARY"
        and artifact.get("artifact_schema_version") == "1"
        and isinstance(artifact.get("summary"), dict)
    )


WORKFLOW = {
    "workflow_id": "SYNTHETIC_NUMBER_SUMMARY_FORMAL",
    "workflow_version": "1",
    "initial_state": "INPUT_READY",
    "canonical_input_schema": {"id": "SYNTHETIC_INTEGER_LIST", "version": "1"},
    "entry_action": "VALIDATE_INPUT",
    "final_authority_condition": {"authority_class": "EMISSION_AUTHORIZED", "terminal": True},
    "output_contract": {
        "id": "SYNTHETIC_NUMBER_SUMMARY_ARTIFACT",
        "version": "1",
        "artifact_validator_reference": "VALIDATE_FORMAL_ARTIFACT",
    },
    "states": {
        "INPUT_READY": {"control_mode": "CONTROLLED_EXECUTION", "authority_class": "CANDIDATE", "terminal": False},
        "INPUT_VALIDATED": {"control_mode": "CONTROLLED_EXECUTION", "authority_class": "AUTHORITATIVE", "terminal": False},
        "SUMMARY_CALCULATED": {"control_mode": "CONTROLLED_EXECUTION", "authority_class": "AUTHORITATIVE", "terminal": False},
        "ARTIFACT_FINALIZED": {"control_mode": "DELIBERATIVE", "authority_class": "EMISSION_AUTHORIZED", "terminal": True},
    },
    "actions": {
        "VALIDATE_INPUT": {
            "allowed_control_mode": "CONTROLLED_EXECUTION",
            "executor_reference": "VALIDATE_INPUT_EXECUTOR",
            "receipt_required": True,
            "success_transition": "INPUT_VALIDATED",
        },
        "CALCULATE_SUMMARY": {
            "allowed_control_mode": "CONTROLLED_EXECUTION",
            "executor_reference": "CALCULATE_SUMMARY_EXECUTOR",
            "receipt_required": True,
            "success_transition": "SUMMARY_CALCULATED",
        },
        "FINALIZE_ARTIFACT": {
            "allowed_control_mode": "CONTROLLED_EXECUTION",
            "executor_reference": "FINALIZE_ARTIFACT_EXECUTOR",
            "receipt_required": True,
            "success_transition": "ARTIFACT_FINALIZED",
        },
    },
    "transitions": [
        {"from_state": "INPUT_READY", "action_id": "VALIDATE_INPUT", "to_state": "INPUT_VALIDATED"},
        {"from_state": "INPUT_VALIDATED", "action_id": "CALCULATE_SUMMARY", "to_state": "SUMMARY_CALCULATED"},
        {"from_state": "SUMMARY_CALCULATED", "action_id": "FINALIZE_ARTIFACT", "to_state": "ARTIFACT_FINALIZED"},
    ],
}

EXECUTORS = {
    "VALIDATE_INPUT_EXECUTOR": validate_input,
    "CALCULATE_SUMMARY_EXECUTOR": calculate_summary,
    "FINALIZE_ARTIFACT_EXECUTOR": finalize_artifact,
}

ARTIFACT_VALIDATORS = {
    "VALIDATE_FORMAL_ARTIFACT": validate_formal_artifact,
}
